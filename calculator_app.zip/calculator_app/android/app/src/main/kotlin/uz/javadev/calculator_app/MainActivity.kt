package uz.javadev.calculator_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
